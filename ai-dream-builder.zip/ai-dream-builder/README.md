# AI Dream Builder

A one-page marketing site with a real "build it free" AI prompt box
and a payments CMS backend.

```
ai-dream-builder/
├── index.html        ← the landing page (open directly, or serve it)
└── backend/           ← Express + SQLite + Stripe + Claude proxy + GitHub push
    ├── server.js
    ├── db.js
    ├── public/admin.html   ← payments CMS dashboard
    ├── package.json
    ├── .env.example
    └── README.md            ← full backend setup docs
```

## Run it locally

**1. Backend** (in one terminal):

```bash
cd backend
npm install
cp .env.example .env
# edit .env with your real Stripe/Anthropic keys
npm start
```

This starts the API at `http://localhost:4000` and the admin CMS at
`http://localhost:4000/admin`.

**2. Frontend** (in another terminal, from the project root):

```bash
npx serve .
# or: python3 -m http.server 5500
```

Open the URL it gives you (e.g. `http://localhost:5500`). Without
this step you can also just double-click `index.html`, but serving
it avoids some browser quirks with `fetch`.

**3. Connect them:** open `index.html`, find this line near the
bottom of the `<script>` tag, and confirm it matches your backend:

```js
const BACKEND_URL = "http://localhost:4000";
```

Once both are running, the "Build it free" box calls Claude for
real, and "Push to GitHub" + the pricing checkout buttons hit your
live backend instead of falling back to preview mode.

See `backend/README.md` for the full endpoint list, Stripe webhook
setup, and the GitHub-push flow's security notes.

## Push this to your own GitHub repo

From this folder:

```bash
git init
git add .
git commit -m "Initial commit — AI Dream Builder"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

(Create the empty repo on GitHub first — github.com/new — without a
README, since you already have one here.)

## Deploying

- **Frontend**: any static host works — GitHub Pages, Vercel, Netlify.
  Just make sure `BACKEND_URL` points at your deployed backend.
- **Backend**: any Node host — Render, Railway, Fly.io, a VPS. See
  `backend/README.md` section 8 for the Stripe webhook + env var
  details you'll need at deploy time.
